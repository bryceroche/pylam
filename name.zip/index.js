
var express = require('express');
var app = express();
var path = require('path');
var server = require('http').createServer(app);  
var AWS = require('aws-sdk');
var urlCrypt = require('url-crypt')('~{ry*I)==yU/]9<7DPk!Hj"R#:-/Z7(hTBnlRS=4CXF');


app.use(express.static(__dirname + '/public'));

const mysql = require('mysql');
const conn = mysql.createConnection({
  host: 'adriras.crk1o9ha4m4n.us-west-2.rds.amazonaws.com',
  user: 'adridba',
  password: 'Adr15ys!mysql',
  database: 'RBSDEMO',
  multipleStatements: true
});


conn.connect((err) => {
  if (err) throw err;
  console.log('Connected! to the database 6');
});

console.log(__dirname + '/public');

app.get('/', (req, res) => {
    console.log('inside the main endpoint -hey! 13');
    //res.sendFile('lp.html', {root: __dirname })
    setkey(conn, donothing, 1, 'somekey')

    

})

function encrypt(data){return urlCrypt.cryptObj(data);}
function decrypt(data){ return urlCrypt.decryptObj(data);}

server.listen(3000, () => console.log('Server running on port 3000'))
server.timeout = 5000;

function donothing() {
  console.log('end ....')
}

function setkey (conn, callback, theid, thekey) {
  con.connect(function(err) {
  if (err) throw err;
  var sql = "update demo_prospects set encrypt_key = " + thekey + " where personid = " + theid + "";
  console.log(sql);
  con.query(sql, function (err, result) {
    if (err) throw err;
    console.log(result.affectedRows + " record(s) updated");
  });
});
};