use chatbot;

select candidateid, count(*) from demo_interview group by 1 order by 1 desc





select * from demo_people  where personcode = 'nbx1094ab3mng20nipo6d4l7mnb8oj4j';

select * from demo_interview where candidateid = 248

select * from vinterview where candidateid = 196


call sp_add_person('o9wwfuhr3hxhgit623215kglzk2m2puv', 'nagi', 'nagi@gmail.c')

call sp_get_managerid('nbx1094ab3mng20nipo6d4l7mnb8oj4j')


select ifnull(max(b.managerid), -1) as managerid

from demo_interview a
join demo_job_openings b on a.roleid = b.roleid and a.locationid = b.locationid
join demo_people c on c.personid = a.candidateid 
where c.personcode = 'nbx1094ab3mng20nipo6d4l7mnb8oj4j';

select * from demo_interview where candidateid = 240
select ifnull(max(b.managerid), -1) as managerid

from demo_interview a
join demo_job_openings b on a.roleid = b.roleid and a.locationid = b.locationid
join demo_people c on c.personid = a.candidateid 
where c.personcode = 'nbx1094ab3mng20nipo6d4l7mnb8oj4j';