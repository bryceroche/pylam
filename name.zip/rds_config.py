#config file containing credentials for rds mysql instance
db_username = "adridba"
db_password = "Adr15ys!mysql"
db_name = "RBSDEMO" 

