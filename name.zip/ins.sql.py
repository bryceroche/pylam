if (any((newtime >= row[0].time() and newtime <= row[2].time()) for row in thedates)):

	cross product of the aval and the interv

	
insert into demo_interview (roleid, managerid, locationid, candidateid, startdate, enddate, loaddate) values (1, 3, 6, 258, '2017-12-30 10:00:00', '2017-12-30 10:20:00', now());
insert into demo_interview (roleid, managerid, locationid, candidateid, startdate, enddate, loaddate) values (1, 3, 6, 258, '2017-12-30 11:00:00', '2017-12-30 11:20:00', now());
insert into demo_interview (roleid, managerid, locationid, candidateid, startdate, enddate, loaddate) values (1, 3, 6, 258, '2017-12-30 11:40:00', '2017-12-30 12:00:00', now());
insert into demo_interview (roleid, managerid, locationid, candidateid, startdate, enddate, loaddate) values (1, 3, 6, 258, '2017-12-30 12:20:00', '2017-12-30 12:40:00', now());