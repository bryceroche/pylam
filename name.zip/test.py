

def asd():
	a = (('sicy', 'sicy@kd', '9424'),)
	print a
	print type(a)

	print a[0][0]
	print a[0][1]
	print a[0][2]


asd()