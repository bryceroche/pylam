ALTER TABLE demo_people ADD  emailed int 



INSERT INTO  demo_prospects (PERSONCODE, fullname, emailaddress, mobilenumber) VALUES('ABCDEFG123', 'Bob Dole', 'bob@dole.com', '424-384-9485')
INSERT INTO  demo_prospects (PERSONCODE, fullname, emailaddress, mobilenumber) VALUES('kjsd', 'Bob Dole2', 'bob2@dole.com', '424-384-9482');
INSERT INTO  demo_prospects (PERSONCODE, fullname, emailaddress, mobilenumber) VALUES('asdee', 'Bob Dole3', 'bob3@dole.com', '424-384-9483');
INSERT INTO  demo_prospects (PERSONCODE, fullname, emailaddress, mobilenumber) VALUES('hkkk', 'Bob Dole4', 'bob4@dole.com', '424-384-9484');
INSERT INTO  demo_prospects (PERSONCODE, fullname, emailaddress, mobilenumber) VALUES('mrbryceroche', 'Bryce Roche', 'bryce.roche@gmail.com', '424-374-6845');
